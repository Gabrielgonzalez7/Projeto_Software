package com.example.projeto_prova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoProvaApplicationTests {

    @Test
    void contextLoads() {
    }

}
