package com.example.projeto_prova.config;

import com.fazecast.jSerialComm.SerialPort;

public class ConexaoPorta {

    private SerialPort serialPort;

    public ConexaoPorta(String portaCOM, int taxa) {
        serialPort = SerialPort.getCommPort(portaCOM);
        serialPort.setBaudRate(taxa);

        if (serialPort.openPort()) {
            System.out.println("Porta aberta: " + portaCOM);
        }
    }

    public void enviaDados(char opcao) {
        if (serialPort != null && serialPort.isOpen()) {
            serialPort.writeBytes(new byte[]{(byte) opcao}, 1);
        }
    }
}
