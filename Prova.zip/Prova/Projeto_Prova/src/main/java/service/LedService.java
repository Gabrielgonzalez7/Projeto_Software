package com.example.projeto_prova.service;

import com.example.projeto_prova.config.ConexaoPorta;
import com.example.projeto_prova.repository.AcaoLedRepository;
import com.example.projeto_prova.model.AcaoLed;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LedService {

    private final AcaoLedRepository repository;
    private final ConexaoPorta conexao;

    public LedService(AcaoLedRepository repository) {
        this.repository = repository;
        this.conexao = new ConexaoPorta("COM4", 9600);
    }

    public void ligar() {
        conexao.enviaDados('1');
        repository.save(new AcaoLed("Está Ligado"));
    }

    public void desligar() {
        conexao.enviaDados('2');
        repository.save(new AcaoLed("Está Desligado"));
    }

    public List<AcaoLed> listar() {
        return repository.findAll();
    }
}