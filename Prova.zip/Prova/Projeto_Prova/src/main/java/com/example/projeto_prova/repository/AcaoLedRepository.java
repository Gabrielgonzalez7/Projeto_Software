package com.example.projeto_prova.repository;

import com.example.projeto_prova.model.AcaoLed;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AcaoLedRepository extends JpaRepository<AcaoLed, Long> {
}