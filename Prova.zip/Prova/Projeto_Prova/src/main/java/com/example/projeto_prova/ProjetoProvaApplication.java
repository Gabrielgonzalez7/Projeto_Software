package com.example.projeto_prova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoProvaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoProvaApplication.class, args);
    }

}