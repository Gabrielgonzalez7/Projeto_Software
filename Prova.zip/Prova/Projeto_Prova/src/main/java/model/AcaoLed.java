package com.example.projeto_prova.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class AcaoLed {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String acao; // LIGADO ou DESLIGADO

    private LocalDateTime dataHora;

    public AcaoLed() {}

    public AcaoLed(String acao) {
        this.acao = acao;
        this.dataHora = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public String getAcao() { return acao; }
    public LocalDateTime getDataHora() { return dataHora; }
}