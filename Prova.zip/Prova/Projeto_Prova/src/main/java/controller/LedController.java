package com.example.projeto_prova.controller;

import com.example.projeto_prova.service.LedService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LedController {

    private final LedService service;

    public LedController(LedService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home(Model model) {
        var historico = service.listar();

        String estado = "DESLIGADO";

        if (!historico.isEmpty()) {
            var ultima = historico.get(historico.size() - 1);

            if (ultima.getAcao().contains("Ligado")) {
                estado = "LIGADO";
            }
        }

        model.addAttribute("historico", historico);
        model.addAttribute("estado", estado);

        return "index";
    }

    @GetMapping("/ligar")
    public String ligar(Model model) {
        service.ligar();
        model.addAttribute("estado", "LIGADO");
        return "redirect:/";
    }

    @GetMapping("/desligar")
    public String desligar(Model model) {
        service.desligar();
        model.addAttribute("estado", "DESLIGADO");
        return "redirect:/";
    }
}