package com.example.CRUD.controller;

import com.example.CRUD.model.Produto;
import com.example.CRUD.repository.ProdutoRepository;
import com.example.CRUD.service.CategoriaService;
import com.example.CRUD.service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("produto")
public class ProdutoController {

    private final ProdutoService produtoService;
    private final CategoriaService categoriaService;

    public ProdutoController(ProdutoService produtoService, CategoriaService categoriaService) {
        this.produtoService = produtoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/formulario")
    public String exibirFormulario(Model model){
        model.addAttribute("produto", new Produto());
        model.addAttribute("categorias", categoriaService.listarCategorias());
        return "formulario";
    }

    @PostMapping("/salvar")
    public String salvarProduto(@ModelAttribute Produto produto){
        produtoService.salvarProduto(produto);
        return "redirect:/produto/listar";
    }

    @GetMapping("/listar")
    public String listarProdutos(Model model){
        List<Produto> produtos = produtoService.listarProdutos();
        model.addAttribute("produtos", produtos);
        return "lista";
    }

    @GetMapping("/deletar/{id}")
    public String deletarProduto(@PathVariable int id){
        produtoService.deletarProduto(id);
        return "redirect:/produto/listar";
    }

    @GetMapping("/editar/{id}")
    public String editarProduto(@PathVariable int id, Model model) {
        Produto produto = produtoService.buscarProdutoPorId(id).orElseThrow();
        model.addAttribute("produto", produto);
        model.addAttribute("categorias", categoriaService.listarCategorias());
        return "formulario";
    }
    }
