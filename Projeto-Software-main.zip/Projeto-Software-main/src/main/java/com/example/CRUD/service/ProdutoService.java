package com.example.CRUD.service;

import com.example.CRUD.model.Produto;
import com.example.CRUD.repository.ProdutoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public void salvarProduto(Produto produto){
        if(produto.getNome() == null || produto.getNome().isBlank()) {
            throw new RuntimeException("O nome do produto é obrigatório");
        }
        if (produto.getValor() <= 0) {
            throw new RuntimeException("O valor do produto deve ser maior que zero");
        }
        produtoRepository.save(produto);
    }
    public List<Produto> listarProdutos(){
        List<Produto> produtos = produtoRepository.findAll();
        return produtos.stream()
                .filter(p -> p.getNome() != null)
                .toList();
    }

    public Optional<Produto> buscarProdutoPorId(int id){
        return produtoRepository.findById(id);
    }

    public void deletarProduto(int id){
        produtoRepository.deleteById(id);
    }

    public Produto atualizarProduto(int id, Produto produto){
        Optional<Produto> produtoExistente = produtoRepository.findById(id);
        if(produtoExistente.isPresent()){
            Produto produtoAtualizado = produtoExistente.get();
            produtoAtualizado.setNome(produto.getNome());
            produtoAtualizado.setValor(produto.getValor());
            return produtoRepository.save(produtoAtualizado);
        }
        throw new RuntimeException("Produto não encontrado");
    }
}
