package com.example.CRUD.controller;

import com.example.CRUD.model.Categoria;
import com.example.CRUD.service.CategoriaService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
@Controller
@RequestMapping("categoria")
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping("/formulario")
    public String exibirFormulario(Model model){
        model.addAttribute("categoria", new Categoria());
        return "formulario-categoria";
    }

    @PostMapping("/salvar")
    public String salvarCategoria(@ModelAttribute Categoria categoria){
        categoriaService.salvarCategorias(categoria);
        return "redirect:/categoria/listar";
    }

    @GetMapping("/listar")
    public String listarCategorias(Model model){
        List<Categoria> categorias = categoriaService.listarCategorias();
        model.addAttribute("categorias", categorias);
        return "lista-categoria";
    }

    @GetMapping("/excluir/{id}")
    public String deletarCategoria(@PathVariable int id){
        categoriaService.deletarCategoria(id);
        return "redirect:/categoria/listar";
    }

    @GetMapping("/editar/{id}")
    public String editarCategoria(@PathVariable int id, Model model) {
        Categoria categoria = categoriaService.buscarCategoriaPorId(id).orElseThrow();
        model.addAttribute("categoria", categoria);
        return "formulario-categoria";
    }


}
