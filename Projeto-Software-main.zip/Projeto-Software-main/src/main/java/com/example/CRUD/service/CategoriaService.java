package com.example.CRUD.service;

import com.example.CRUD.model.Categoria;
import com.example.CRUD.repository.CategoriaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public void salvarCategorias(Categoria categorias) {
        if (categorias.getNome() == null || categorias.getNome().isBlank()) {
            throw new RuntimeException("O nome da categoria é obrigatório");
        }
        categoriaRepository.save(categorias);
    }

    public List<Categoria> listarCategorias() {
        List<Categoria> categorias = categoriaRepository.findAll();
        return categorias.stream()
                .filter(c -> c.getNome() != null)
                .toList();
    }

    public Optional<Categoria> buscarCategoriaPorId(int id) {
        return categoriaRepository.findById(id);
    }
    public void deletarCategoria(int id){
        categoriaRepository.deleteById(id);
    }

    public Categoria atualizarCategoria(int id, Categoria categoria) {
        Optional<Categoria> categoriaExistente = categoriaRepository.findById(id);
        if (categoriaExistente.isPresent()) {
            Categoria categoriaAtualizada = categoriaExistente.get();
            categoriaAtualizada.setNome(categoria.getNome());
            return categoriaRepository.save(categoriaAtualizada);
        }
        throw new RuntimeException("Categoria não encontrada");
    }
}
