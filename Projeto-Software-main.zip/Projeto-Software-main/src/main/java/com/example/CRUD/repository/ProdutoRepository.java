package com.example.CRUD.repository;

import com.example.CRUD.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository <Produto, Integer> {
}
