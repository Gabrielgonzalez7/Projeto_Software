/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package projeto1;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author gabri
 */
public class ProdutoDAO {
private final String ARQUIVO = "produtos.csv";
    
    public void salvar(Produto produto) throws IOException{
        File arquivo = new File(ARQUIVO);
        boolean existe = arquivo.exists();
        
        FileWriter writer = new FileWriter(arquivo, true);
        
        if(!existe){
            writer.write("Código,Nome,Descrição,Preço,Quantidade");
        }
        
        writer.write(produto.toCSV() + "\n");
        writer.close();
        }
    
}
