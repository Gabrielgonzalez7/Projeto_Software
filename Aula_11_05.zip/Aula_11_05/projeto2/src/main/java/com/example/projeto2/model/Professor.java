package com.example.projeto2.model;


import jakarta.persistence.*;
import java.util.List;

@Entity
public class Professor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nome;

    private String email;

    private String especialidade;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "professor_id")
    private List<Telefone> telefones;

}
