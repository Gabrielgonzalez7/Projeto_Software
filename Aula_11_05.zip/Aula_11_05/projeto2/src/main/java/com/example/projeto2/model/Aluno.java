package com.example.projeto2.model;


import jakarta.persistence.*;

@Entity
@Table(name = "Estudantes")
public class Aluno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nome;

    @Column(unique=true, nullable=false)
    private String cpf;

    @Column(unique=true, nullable=false)
    private String email;

    @ManyToOne
    @JoinColumn(name = "curso_id")
    private Curso curso;

}
