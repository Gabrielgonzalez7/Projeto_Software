package com.example.projeto2.model;

public enum SalaTipo {
    LABORATORIO, AUDITORIO, NORMAL

}
