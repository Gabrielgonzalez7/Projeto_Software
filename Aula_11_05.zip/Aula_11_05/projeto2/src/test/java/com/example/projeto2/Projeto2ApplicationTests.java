package com.example.projeto2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
